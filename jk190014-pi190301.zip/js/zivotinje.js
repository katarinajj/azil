$(document).ready(function() {
    $(".zivotinja-pas").click(function() {
            window.location.href = "./zivotinje/psi.html";
        }        
    );
    $(".zivotinja-macka").click(function() {
            window.location.href = "./zivotinje/macke.html";
        }        
    );
    $(".zivotinja-ptica").click(function() {
            window.location.href = "./zivotinje/ptice.html";
        }        
    );
});