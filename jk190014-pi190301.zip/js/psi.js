jedan = {
    ime: "Boni",
    rasa: ["labrador", "labrador"],
    pol: ["ženka", "female"],
    starost: ["1 godina", "1 year"],
    tezina: "25kg",
    opis: ["Umiljat pas, želi vlasnika sa kojim će da trči!", "Cute dog, he wants an owner to run with!"],
    slika: ["../slike/labrador.png", "../slike/labrador2.png"],
    link: "./psi/labrador.html"
};

dva = {
    ime: "Flipi",
    rasa: ["samojed", "samoyed"],
    pol: ["mužjak", "male"],
    starost: ["3 godine", "3 years"],
    tezina: "25kg",
    opis: ["Umiljat pas, želi vlasnika sa kojim će da se mazi!","Cute dog, he wants an owner to cuddle with!"],
    slika: ["../slike/samojed.png", "../slike/samojed2.png"],
    link: "./psi/samojed.html"
};

tri = {
    ime: "Doli",
    rasa: ["pudlica", "poodle"],
    pol: ["ženka", "female"],
    starost: ["4 godine", "4 years"],
    tezina: "15kg",
    opis: ["Umiljat pas, želi vlasnika koji će da je voli!","Cute dog, he wants an owner who will love her!"],
    slika: ["../slike/pudlica.png", "../slike/pudlica2.png"],
    link: "./psi/pudlica.html"
};


niz = [jedan, dva, tri];