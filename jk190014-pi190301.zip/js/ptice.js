jedan = {
    ime: "Koko",
    rasa: ["kanarinac", "canary"],
    pol: ["mužjak", "male"],
    starost: ["1 godina", "1 year"],
    tezina: "50g",
    opis: ["Veseo kanarinac, voli da leti!", "Cheerful canary, loves to fly!"],
    slika: ["../slike/kanarinac.png", "../slike/kanarinac2.png"],
    link: "./ptice/kanarinac.html"
};


dva = {
    ime: "Klaudija",
    rasa: ["nimfa", "nimfa"],
    pol: ["ženka", "female"],
    starost: ["3 godine", "3 years"],
    tezina: "28g",
    opis: ["Veseli predstavnik porodice kakadua!", "Cheerful representative of the cockatoo family!"],
    slika: ["../slike/nimfa.png", "../slike/nimfa2.png"],
    link: "./ptice/nimfa.html"
};

tri = {
    ime: "Mina i Tina",
    rasa: ["tigrice", "tigers"],
    pol: ["ženka", "female"],
    starost: ["4 godine", "4 years"],
    tezina: "40g",
    opis: ["Dva pričljiva i vesela prijatelja sa krilima!", "Two talkative and cheerful friends with wings!"],
    slika: ["../slike/tigrica.png", "../slike/tigrica2.png"],
    link: "./ptice/tigrice.html"
};


niz = [jedan, dva, tri];