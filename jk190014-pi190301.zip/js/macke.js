jedan = {
    ime: "Keti",
    rasa: ["persijska", "persian"],
    pol: ["ženka", "female"],
    starost: ["2 godine", "2 years"],
    tezina: "7kg",
    opis: ["Umiljata maca, voli mnogo da spava!", "Cute cat, likes to sleep a lot!"],
    slika: ["../slike/persijska.png", "../slike/persijska2.png"],
    link: "./macke/persijska.html"
};

dva = {
    ime: "Beti",
    rasa: ["bengalska", "bengal"],
    pol: ["ženka", "female"],
    starost: ["4 godine", "4 years"],
    tezina: "9kg",
    opis: ["Umiljata maca, voli mnogo da spava!", "Cute cat, likes to cuddle a lot!"],
    slika: ["../slike/bengalska.png", "../slike/bengalska2.png"],
    link: "./macke/bengalska.html"
};

tri = {
    ime: "Tifi",
    rasa: ["sijamska", "siamese"],
    pol: ["mužjak", "male"],
    starost: ["1 godina", "1 year"],
    tezina: "5kg",
    opis: ["Umiljata maca, voli mnogo da spava!", "Cute cat, likes to play a lot!"],
    slika: ["../slike/sijamska.png", "../slike/sijamska2.png"],
    link: "./macke/sijamska.html"
};


niz = [jedan, dva, tri];

